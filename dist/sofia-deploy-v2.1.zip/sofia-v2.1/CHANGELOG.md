SOFIA v2.1 — Release Notes
===========================
Fecha: 2026-03-26

NUEVAS CAPACIDADES v2.1
────────────────────────

[QA TESTER — INTEGRATION TESTS EXPERTISE]
• qa-tester/SKILL.md actualizado con lecciones aprendidas de BankPortal Sprint 19
  - Las 4 causas raíz documentadas: test scope, interfaces sin impl, schema drift, env parity
  - Pirámide de testing obligatoria con nivel 5 (Integration) SIEMPRE requerido en backend
  - Paso 2b OBLIGATORIO: auditoría de integration tests antes de aprobar cualquier sprint
  - GAP BLOQUEANTE: 0 integration tests en backend = el sprint no puede cerrarse
  - 10 Reglas de oro (vs 8 en v2.0)
  - Regla #10: SpringContextIT es el primer test que se crea en cualquier proyecto backend
  - Exit criteria actualizados: SpringContextIT PASS + DatabaseSchemaIT PASS obligatorios
  - Auditoria IT en plantilla de QA Report con 7 checks

[INTEGRATION TESTS — PLANTILLAS COMPLETAS]
• templates/integration-tests/ — plantillas listas para usar en cualquier proyecto
  - IntegrationTestBase.java — base con Testcontainers, singleton pattern, @DynamicPropertySource
  - SpringContextIT.java — detecta beans faltantes, ambigüedad y properties no configuradas
  - DatabaseSchemaIT.java — detecta schema drift (columnas incorrectas) antes de STG
  - [Adapter]IT.java — verifica SQL de repositorios contra BD real, patron por puerto de dominio
  - AuthIT.java — flujo de autenticación completo con BD real
  - application-test.yml — perfil de test con todas las properties necesarias
  Stacks soportados:
  - Java / Spring Boot 3.x + Testcontainers + @SpringBootTest
  - .Net / ASP.NET Core + Testcontainers + WebApplicationFactory
  - Angular + MSW (Mock Service Worker) con contrato OpenAPI

[CI PIPELINE — GITHUB ACTIONS]
• ci/.ci.yml — pipeline de 4 jobs obligatorios:
  - Job 1: Unit Tests (*Test.java) — rápido, sin Docker
  - Job 2: Integration Tests (*IT.java + PostgreSQL Testcontainers) — detecta schema drift y beans
  - Job 3: Frontend Build (Angular + ng build + locale check) — detecta NG0701 en build
  - Job 4: Smoke Tests en stack completo (solo en merge a main)
• Bloquea merge a main si cualquier job falla
• Integration tests como job SEPARADO — no mezclado con unit tests

[SCRIPTS]
• scripts/run-integration-tests.sh — ejecución local de tests con flags --unit-only / --it-only
• Requiere Docker en local para Testcontainers

ERRORES PREVENIDOS POR ESTAS CAPACIDADES
──────────────────────────────────────────
Estos errores se detectarían en CI antes de llegar a STG:
• NoSuchBeanDefinitionException — bean faltante (SpringContextIT)
• BadSqlGrammarException — columna inexistente (DatabaseSchemaIT + AdapterIT)
• UnsatisfiedDependencyException — beans duplicados/ambiguos (SpringContextIT)
• IllegalArgumentException — properties no definidas (application-test.yml completo)
• NG0701 — locale no registrado en Angular (Frontend Build job)
• 401 incorrectos — SecurityConfig mal configurada (AuthIT)

CAPACIDADES CONSOLIDADAS v2.1
───────────────────────────────
• 20 skills activos
• Pipeline de 14 steps con FA-Agent en 2b/3b/8b
• Dashboard Global regenerado en cada Gate
• Documentation Agent: 10 Word + 3 Excel por sprint
• CMMI Level 3: 9 PAs con evidencias
• Atlassian MCP: Jira + Confluence sincronizados
• QA Tester: pirámide completa con integration tests obligatorios
• CI Pipeline: 4 jobs (unit + IT + frontend + smoke)
• Integration test templates para Java, .Net y Angular

MÉTRICAS BankPortal (Sprint 19 — en curso)
────────────────────────────────────────────
• Sprint 19: FEAT-017 Domiciliaciones (en desarrollo)
• Tests: 69 unitarios + 14 integration tests (NUEVO en v2.1)
• STG: stack Docker completamente operativo
• Integration tests creados en DEBT-030: SpringContextIT, DashboardJpaAdapterIT, LoginControllerIT, AccountRepositoryAdapterIT

COMPATIBILIDAD
──────────────
• Compatible con proyectos existentes SOFIA v1.x y v2.0
• Requiere: Java 21, Spring Boot 3.3+, Testcontainers 1.19+
• No requiere cambios en el pipeline existente
• qa-tester.skill es retrocompatible — nuevas reglas son aditivas
