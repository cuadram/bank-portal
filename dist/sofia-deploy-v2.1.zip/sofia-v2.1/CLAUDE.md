# SOFIA v2.1 — Software Factory IA · Experis

## REGLA CRÍTICA DE SESIÓN — LA-018-01

Al inicio de CUALQUIER sesión de continuación de pipeline:
1. Leer `.sofia/session.json` antes de cualquier acción
2. Si `gate_pending != null` → solicitar aprobación del gate pendiente antes de avanzar
3. El sprint NO está cerrado hasta que Step 9 aparezca en `completed_steps` con status COMPLETED Y Atlassian esté sincronizado
4. Nunca asumir que el pipeline se completó basándose solo en artefactos en disco

## REGLA CRÍTICA — DASHBOARD GLOBAL (v2.1)

El Dashboard Global `docs/dashboard/[proyecto]-global-dashboard.html` es un **entregable oficial del proyecto**.

**Cuándo regenerar — OBLIGATORIO:**
- En CADA aprobación de Gate (G-1 a G-9), ejecutar inmediatamente después:
  ```
  /opt/homebrew/opt/node@22/bin/node .sofia/scripts/gen-global-dashboard.js --gate G-[N] --step [N]
  ```
- Un Gate NO está completamente procesado hasta que el Dashboard Global está actualizado en disco
- Verificación: `session.json.dashboard_global.last_generated` debe actualizarse

## REGLA CRÍTICA — INTEGRATION TESTS (v2.1)

**Los integration tests son SIEMPRE obligatorios en proyectos backend.**

- 0 integration tests = GAP BLOQUEANTE — el sprint no puede aprobarse
- El QA Tester audita con checklist de 7 puntos en Paso 2b (obligatorio)
- SpringContextIT es el PRIMER test que se crea en cualquier proyecto backend
- El CI pipeline ejecuta integration tests en job SEPARADO (Job 2)

```bash
# Ejecutar integration tests localmente
./scripts/run-integration-tests.sh --it-only
```

## Skill Loader v2.1

---

## Inicialización automática (ejecutar en cada sesión)

```
1. Lee: .sofia/skills/orchestrator/SKILL.md
2. Lee: .sofia/session.json          ← estado del pipeline
3. Lee: .sofia/sofia-config.json     ← configuración del proyecto
4. Verifica gate_pending — si existe, solicitar aprobación antes de continuar
5. Verifica session.json.dashboard_global.last_generated
```

---

## Pipeline estándar v2.1 (14 steps)

| Step | Agente               | Skill path                              | Gate      |
|------|----------------------|-----------------------------------------|-----------|
| 1    | Scrum Master         | scrum-master/SKILL.md                   | HITL PO   |
| 2    | Requirements Analyst | requirements-analyst/SKILL.md           | HITL PO   |
| 2b   | FA-Agent             | fa-agent/SKILL.md                       | AUTO      |
| 3    | Architect            | architect/SKILL.md                      | HITL TL   |
| 3b   | Doc Agent + FA-Agent | documentation-agent + fa-agent          | AUTO      |
| 4    | Developer            | java/dotnet/angular-developer + core    | —         |
| 5    | Code Reviewer        | code-reviewer/SKILL.md                  | HITL TL   |
| 5b   | Security Agent       | security-agent/SKILL.md                 | AUTO*     |
| 6    | QA Tester            | qa-tester/SKILL.md                      | HITL QA   |
| 7    | DevOps               | devops/SKILL.md                         | HITL DV   |
| 8    | Documentation Agent  | documentation-agent/SKILL.md            | HITL PM   |
| 8b   | FA-Agent             | fa-agent/SKILL.md                       | AUTO      |
| 9    | Workflow Manager     | workflow-manager/SKILL.md               | —         |

*AUTO con gate BLOQUEANTE si CVE críticos > 0

---

## Agentes disponibles (20)
- Orchestrator · Scrum Master · Requirements Analyst · FA-Agent
- Architect · Developer Core · Java/Net/Node/Angular/React Developer
- Code Reviewer · QA Tester · Security Agent · Performance Agent
- DevOps · Jenkins Agent · Documentation Agent · Workflow Manager · Atlassian Agent

---

## ⚠️ Persistence Protocol — OBLIGATORIO

Todo agente que genere artefactos DEBE:
1. Escribir artefactos a disco antes de cerrar su paso
2. Confirmar con bloque ✅ PERSISTIDO listando cada archivo y ruta
3. El Orchestrator actualiza session.json y añade entrada a sofia.log

**El Orchestrator NO avanza al siguiente step sin bloque de confirmación.**

---

## Historial de versiones

- **v2.1 (2026-03-26): QA Tester con integration tests obligatorios, CI pipeline 4 jobs, plantillas Testcontainers**
- v2.0 (2026-03-26): FA-Agent, Dashboard Global entregable, pipeline 14 steps, 20 agentes
- v1.9 (2026-03-24): Security Agent Step 5b, Dashboard Global, CMMI evidence gates
- v1.8 (2026-03-19): Performance Agent, multi-proyecto
- v1.7 (2026-03-17): Documentation Agent Steps 3b+8
- v1.5 (2026-03-15): Persistence Protocol
- v1.1 (2026-03-12): Documentation Agent inicial
