# SOFIA v2.1 — Software Factory IA · Experis

## Instalación rápida

```bash
unzip sofia-deploy-v2.1.zip -d /tu/proyecto/.sofia
bash .sofia/scripts/setup-sofia-mac.sh
```

## Qué hay en este paquete

| Directorio | Contenido |
|---|---|
| `skills/` | 20 SKILL.md — uno por agente |
| `scripts/` | Scripts de generación, dashboard, CI |
| `templates/` | Plantillas Word, Excel, integration tests |
| `config/` | sofia-config.json, PERSISTENCE_PROTOCOL.md |
| `ci/` | GitHub Actions pipeline (4 jobs) |

## Novedades v2.1 — Integration Tests Obligatorios

El skill qa-tester ahora exige integration tests en TODOS los proyectos backend.

**El QA audita con 7 checks antes de aprobar cada sprint:**
- IntegrationTestBase con Testcontainers configurado
- SpringContextIT — el contexto Spring arranca sin errores
- DatabaseSchemaIT — columnas y tablas validadas contra BD real
- IT por cada puerto de dominio
- AuthIT — flujo de autenticación contra BD real
- application-test.yml completo
- CI pipeline con job de ITs separado

**Plantillas en** `templates/integration-tests/`:
- `IntegrationTestBase.java` (Java/Spring Boot)
- `SpringContextIT.java`
- `DatabaseSchemaIT.java`
- `[Adapter]IT.java`
- `AuthIT.java`
- `application-test.yml`
- `.Net/WebApplicationFactory base` (en comentarios)
- `Angular/MSW server setup` (en comentarios)

**CI Pipeline** `ci/ci.yml` — 4 jobs:
1. Unit Tests (sin Docker, rápido)
2. Integration Tests (Testcontainers + PostgreSQL real)
3. Frontend Build (Angular + locale check)
4. Smoke Tests (stack completo, solo en main)

**Ejecutar localmente:**
```bash
./scripts/run-integration-tests.sh          # todos
./scripts/run-integration-tests.sh --it-only  # solo integration
```

## Por qué son obligatorios

Sin integration tests, el CI pasa pero el entorno falla porque:
1. Los beans de Spring no se instancian nunca en tests unitarios
2. El SQL se escribe sin validar contra el schema real de BD
3. Las properties custom no se verifican hasta que Spring arranca completo
4. Los locales de Angular no se detectan en compilación si no hay build job

Un `SpringContextIT` que falla en CI detecta en minutos lo que cuesta horas depurar en STG.

## Versiones

- **v2.1** — Integration tests obligatorios, CI pipeline, plantillas Testcontainers
- **v2.0** — FA-Agent, Dashboard Global entregable, 20 agentes, pipeline 14 steps
- **v1.9** — Security Agent, CMMI evidence gates
